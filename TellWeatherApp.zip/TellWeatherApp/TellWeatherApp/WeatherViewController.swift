//
//  ViewController.swift
//  TellWeatherApp
//
//  Created by Britty Bidari on 29/08/2021.
//
import UIKit
import CoreLocation
import Combine
struct ExpansionCell{
    var title: String
    var Data: [String]
    var isOpened:Bool = false
    init (title:String,Data:[String], isOpened:Bool = false){
        self.title = title
        self.Data = Data
        self.isOpened = false
    }
}
private var sections = [ExpansionCell]()
class WeatherViewController: UIViewController,CLLocationManagerDelegate,UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var citySearchField: UITextField!
    @IBOutlet weak var searchPlace: UIButton!
    @IBOutlet weak var textFieldGroup: UIStackView!
    @IBOutlet weak var place: UILabel!
    @IBOutlet weak var weatherDescription: UILabel!
    @IBOutlet weak var temperatureFahrenheit: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var CityListView: UIView!
    private var locationManager:CLLocationManager!
    private var weatherFetcher:WeatherFetcher!
    private var disposable = Set<AnyCancellable>()
    private var weatherSummary: WeatherSummary?
    private var daySummary: DaySummary?
    var arrayPlaces = [String]()
    var currentTempFmt: String {
        guard let temp = weatherSummary?.current.actualTemp.fahrenheight else { return "--º" }
        return String(format: "%.0fº", temp)
    }
    var feelsLikeTempFmt: String {
        guard let temp = weatherSummary?.current.feelsLikeTemp.fahrenheight else { return "--º" }
        return String(format: "%.0fº", temp)
    }
    var currentTempDescription: String {
        guard let description = weatherSummary?.current.weatherDetails.first?.weatherDescription else {
            return ""
        }
        return description.localizedCapitalized
    }
    var daySummaries: [DaySummary] = []
    //    var ViewLoader:LoaderViewController = LoaderViewController()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.dataSource = self
        tableView.delegate = self
        citySearchField.delegate = self
        weatherFetcher = DataManager()
        if CLLocationManager.locationServicesEnabled()
        {
            locationManager = CLLocationManager()
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.requestWhenInUseAuthorization()
            locationManager.requestLocation()
        }
        self.updateViews()
        self.recentSearchFetch()
        CityListView.backgroundColor = UIColor (named: "PrimaryAppColor")
        CityListView.superview?.bringSubviewToFront(CityListView)
        CityListView.isHidden = true
        citySearchField.addTarget(self, action: #selector(myTargetFunction), for: .touchDown)
    }
    //Calls this function when the tap is recognized.
    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    @IBAction func textFieldClick(_ sender: Any) {
        //        citySearchField.resignFirstResponder()
        //        CityListView.isHidden = false
    }
    @objc func myTargetFunction(textField: UITextField) {
        //Looks for single or multiple taps.
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
        //Uncomment the line below if you want the tap not not interfere and cancel other interactions.
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    @IBAction func closeCityList(_ sender: Any) {
        CityListView.isHidden = true
    }
    func recentSearchFetch(){
        let listCity = getData()
        for everyCity in listCity {
            let expansionCell = ExpansionCell(title: everyCity, Data: [""],isOpened: false)
            sections.append(expansionCell)
        }
        tableView.reloadData()
    }
    func recentSearchFetch(sectionTitleString:String){
        fetchWeatherSummary(forCity: sectionTitleString)
        if let description = weatherSummary?.current.weatherDetails.first?.weatherDescription{
            weatherDescription.text = description.localizedCapitalized
        }
        place.text =  weatherSummary?.timezone.capitalized
        if let temperature = weatherSummary?.current.actualTemp.fahrenheight{
            temperatureFahrenheit.text = String(format:"%.0f°F",temperature)
        }
        tableView.reloadData()
    }
    //MARK: -core location to fetch local locations
    func locationManager(
        _ manager: CLLocationManager,
        didUpdateLocations locations: [CLLocation]
    ) {
        if let location = locations.first {
            let latitude = location.coordinate.latitude
            let longitude = location.coordinate.longitude
            // Handle location update
            fetchWeatherSummary(for:location.coordinate)
            print("latitude: \(latitude) \nlongitude: \(longitude)")
        }
    }
    func locationManager(
        _ manager: CLLocationManager,
        didFailWithError error: Error
    ) {
        print("Error in location fetch")
    }
    //MARK: - API FUNCTION to fetch the weather data based on coordinates and city
    func fetchWeatherSummary(for coordinate:CLLocationCoordinate2D ){
        tableView.reloadData()
        weatherFetcher.weatherSummary(for: coordinate)
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { [weak self] (value) in
                switch value {
                case .failure(let error):
                    self?.weatherSummary = nil
                    self?.daySummaries = []
                    print(error)
                case .finished:
                    break
                }
            }) { [weak self] weatherSummary in
                self?.weatherSummary = weatherSummary
                self?.daySummaries = weatherSummary.daily.map { DaySummary(daySummary: $0) }
                self?.updateViews()
            }.store(in: &disposable)
        
    }
    func fetchWeatherSummary(forCity city: String ){
        tableView.reloadData()
        weatherFetcher.weatherSummary(forCity : city)
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { [weak self] (value) in
                switch value {
                case .failure(let error):
                    self?.weatherSummary = nil
                    self?.daySummaries = []
                    print(error)
                case .finished:
                    break
                }
            }) { [weak self] weatherSummary in
                self?.weatherSummary = weatherSummary
                self?.daySummaries = weatherSummary.daily.map { DaySummary(daySummary: $0) }
                self?.updateCity(city: city)
            }.store(in: &disposable)
    }
    func fetchWeatherSummaryDetail(forCity city: String) -> String {
        fetchWeatherSummary(forCity : city)
        print (city)
        if let temperature = weatherSummary?.current.actualTemp.fahrenheight{
            return  String(format:"%.0f°F",temperature)
        }
        return ""
    }
    func updateViews(){
        if let description = weatherSummary?.current.weatherDetails.first?.weatherDescription{
            weatherDescription.text = description.localizedCapitalized
        }
        place.text =  weatherSummary?.timezone.capitalized
        if let temperature = weatherSummary?.current.actualTemp.fahrenheight{
            temperatureFahrenheit.text = String(format:"%.0f°F",temperature)
        }
        tableView.reloadData()
    }
    func updateCity(city:String){
        if let description = weatherSummary?.current.weatherDetails.first?.weatherDescription{
            weatherDescription.text = description.localizedCapitalized
        }
        place.text = city
        if let temperature = weatherSummary?.current.actualTemp.fahrenheight{
            temperatureFahrenheit.text = String(format:"%.0f°F",temperature)
        }
        tableView.reloadData()
    }
    //MARK: - user defaults
    func setData(places : String){
        let defaults = UserDefaults.standard
        var searchList = getData()
        if(!searchList.contains(places.uppercased())){
            searchList.append(places.uppercased())
            defaults.set(searchList, forKey:"placeAdd" )
        }
    }
    func getData()->[String]{
        let defaults = UserDefaults.standard
        let placeArray = defaults.stringArray(forKey: "placeAdd")
        return placeArray ?? []
    }
    //MARK: - click button
    @IBAction func searchPlaceButton(_ sender: Any) {
    
        fetchWeatherSummary(forCity:citySearchField.text ?? "Banglore")
        if let description = weatherSummary?.current.weatherDetails.first?.weatherDescription{
            weatherDescription.text = description.localizedCapitalized
        }
        place.text =  citySearchField.text
        if let temperature = weatherSummary?.current.actualTemp.fahrenheight{
            temperatureFahrenheit.text = String(format:"%.0f°F",temperature)
        }
        setData(places:citySearchField.text ?? "Banglore")
        print(sections)
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: { [self] in
            if let temperature = self.weatherSummary?.current.actualTemp.fahrenheight{
                self.temperatureFahrenheit.text = String(format:"%.0f°F",temperature)
                
            }
            let expansionCell = ExpansionCell(title:self.citySearchField.text?.uppercased() ?? "" , Data: [ self.temperatureFahrenheit.text ?? "This is temperature"],isOpened: false)
            sections.append(expansionCell)
            tableView.reloadData()
        })
       
        
    }
    //MARK: -table Delegate Properties
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        fetchWeatherSummary(forCity: sections[indexPath.section].title )
        if let description = weatherSummary?.current.weatherDetails.first?.weatherDescription{
            weatherDescription.text = description.localizedCapitalized
        }
        place.text =  sections[indexPath.section].title
        if let temperature = weatherSummary?.current.actualTemp.fahrenheight{
            tableView.reloadData()
            temperatureFahrenheit.text = String(format:"%.0f°F",temperature)
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(Int(1)), execute: {
                self.fetchWeatherSummary(forCity: sections[indexPath.section].title )
                sections[indexPath.section].Data[0] = String(format:"This is the temperature %.0f°F",self.weatherSummary?.current.actualTemp.fahrenheight ?? "")
            })
        }
        if indexPath.row == 0{
            if  sections[indexPath.section].isOpened{
                sections[indexPath.section].isOpened = false
            }else{
                sections[indexPath.section].isOpened = true
                updateViews()
            }
            let sectionCount:Int =  sections.count - 1
            for i in 0...sectionCount{
                if(sections[i].title != sections[indexPath.section].title){
                    sections[i].isOpened = false
                }
            }
        }
        if indexPath.row != 0
        {
            let storyBoard : UIStoryboard = UIStoryboard(name: "DetailStoryboard", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
            let description = weatherSummary?.current.weatherDetails.first?.weatherDescription
            nextViewController.weatherDescriptionText = description?.localizedCapitalized ?? ""
            nextViewController.weatherDestinyText =  sections[indexPath.section].title
            if let temperature = weatherSummary?.current.actualTemp.fahrenheight{
                nextViewController.temperatureDetailText = String(format:"%.0f°F",temperature)
            }
            self.present(nextViewController, animated:true, completion:nil)
            print("Detail Tapped")
            let indexCount = (sections.firstIndex {$0.title != sections[indexPath.section].title} != nil)
            Swift.print (indexCount)
            let sectionCount:Int =  sections.count - 1
            for i in 0...sectionCount{
                 sections[i].isOpened = false
            }
        }
        print("Detail Tapped")
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let section = sections[section]
        if section.isOpened{
            return section.Data.count + 1 // all row + main row
        }else{
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.selectionStyle != UITableViewCell.SelectionStyle.none
        if indexPath.row == 0 {
            cell.textLabel?.text = sections[indexPath.section].title
        }else{
            cell.textLabel?.text = sections[indexPath.section].Data[indexPath.row-1]
        }
        return cell
    }
}
