//
//  CityListModel.swift
//  TellWeatherApp
//
//  Created by Britty Bidari on 30/08/2021.
//

import Foundation

public class CityListModel:Decodable{
    public var id:Int?
    
    public var state:String?
   
    public var coord:Coord?
    public var country:String?
    public var geoname:GeoName?
    public var langs:[Langs]?
    
    public var name:String?
    public var stat:Stat?
    public var station:[Station]?
    
    public var zoom:Int?
}

public class Coord:Decodable{
    public var lon:Float
    public var lat:Float
}

public class GeoName:Decodable{
    public var cl:String?
    public var code:String?
    public var parent:String?
}

public class Langs:Decodable{
    public var de:String?
    public var fa:String?
}

public class Stat:Decodable{
    public var level:Float?
    public var Population:Int?
}
public class Station:Decodable{
    public var stationId:Int?
    public var dist:Int?
    public var kf:Int?
}
