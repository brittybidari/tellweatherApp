//
//  DetailViewController.swift
//  TellWeatherApp
//
//  Created by Britty Bidari on 29/08/2021.
//

import UIKit


class DetailViewController: UIViewController {
    public var weatherDestinyText = ""
    public var weatherDescriptionText = ""
    public var temperatureDetailText = ""
    
    @IBOutlet weak var weatherDestiny: UILabel!
    @IBOutlet weak var weatherDescription: UILabel!
    @IBOutlet weak var TemperatureDetail: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        weatherDestiny.text = weatherDestinyText
        weatherDescription.text = weatherDescriptionText
        TemperatureDetail.text = temperatureDetailText
        // Do any additional setup after loading the view.
        
        if(weatherDescriptionText.lowercased().contains("clouds")){
            self.view.backgroundColor = (UIColor (named: "storm"))
        }else if((weatherDescriptionText.lowercased().contains("rain"))){
            self.view.backgroundColor = (UIColor (named: "Blue"))
        }
        else{
            self.view.backgroundColor = (UIColor (named: "Yellow"))
        }
    }
    
    @IBAction func closeSelfButton(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
     

}
