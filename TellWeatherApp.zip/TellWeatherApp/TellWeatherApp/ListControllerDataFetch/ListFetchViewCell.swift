//
//  ListFetchViewCell.swift
//  weather
//
//  Created by Britty Bidari on 30/08/2021.
//

import UIKit

class ListFetchViewCell: UICollectionViewCell {
    
    @IBOutlet weak var weatherImageIcon: UIImageView!
    @IBOutlet weak var dateValue: UILabel!
    @IBOutlet weak var dayValue: UILabel!
    @IBOutlet weak var expandList: UIButton!
    @IBOutlet weak var placeName: UILabel!
}
